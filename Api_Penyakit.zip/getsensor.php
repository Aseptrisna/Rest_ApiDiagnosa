<?php
include './controller/sensor.php';
include_once('./config/koneksi.php');
getdatasensor($con);
?>